#include<iostream>
using namespace std;
int main()
{
	float x,y,z;
	cout<<"Ingrese 2 numeros separados de espacio x y:";
	cin>>x>>y;
        z=x+y;
	cout<<"El resultado es:";
        cout<<z<<endl;
	return 0;
}
